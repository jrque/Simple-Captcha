/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zzz;

/**
 *
 * @author J
 */
public class TestEncryption {

	public static void main(String[] args) 
	{
	
		 System.out.println(Security.encrypt("university of santo tomas"));
                // System.out.println(Security.decrypt("X03O/bZKNujj5EHOnGB41TLCWUWlvxtbMA9dViDNg9o="));
                //System.out.println(Security.decrypt("+dcrgAbzQxC16Oogbp1W4efGxGjVyfgTWzx/AXWK5Uo="));
        
        }
}

// X03O/bZKNujj5EHOnGB41TLCWUWlvxtbMA9dViDNg9o=
// university of santo tomas
// 0x74, 0x68, 0x69, 0x73, 0x49, 0x73, 0x41, 0x53, 0x65, 0x63, 0x72, 0x65, 0x74, 0x4b, 0x65, 0x79

// +dcrgAbzQxC16Oogbp1W4efGxGjVyfgTWzx/AXWK5Uo=
// university of santo tomas
// lawrencedecamora

